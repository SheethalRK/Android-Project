package demo.technosteam;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class billone extends AppCompatActivity {
    EditText t1, t2,t3,t4,t5;

    String s1, s2,s3,s4,s5, ReturnValue;

    public void save(View v) {
        s1 = t1.getText().toString();
        s2 = t2.getText().toString();
        s3 = t3.getText().toString();
        s4 = t4.getText().toString();

        s5 = t5.getText().toString();


        if(s1.equals("")&&s2.equals("")&&s3.equals("")&&s4.equals("")&&s5.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Order ID cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Customer ID cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s3.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Bill number cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s4.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Total ammount cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s5.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Mode of payment cannot be blank",Toast.LENGTH_LONG).show();
        }

        else {

            String strurl = "http://192.168.43.138/technosteam/bill.php";
            new billdetails().execute(strurl);
        }
    }
    String oid,custid,gtotal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);
        t1 = (EditText) findViewById(R.id.editText70);
        t2 = (EditText) findViewById(R.id.editText71);
        t3 = (EditText) findViewById(R.id.editText72);
        t4 = (EditText) findViewById(R.id.editText73);
        t5 = (EditText) findViewById(R.id.editText74);

        Bundle bb=getIntent().getExtras();

        oid=bb.getString("oid");
        custid=bb.getString("custid");
        gtotal=bb.getString("gtotal");
        t1.setText(oid);
        t2.setText(custid);
        t3.setText(gtotal);



    }

    private class billdetails extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));
            nameValuePairs.add(new BasicNameValuePair("s3", s3));
            nameValuePairs.add(new BasicNameValuePair("s4", s4));
            nameValuePairs.add(new BasicNameValuePair("s5", s5));


            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;
            return null;


        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "connecting", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();

        }
    }
}



