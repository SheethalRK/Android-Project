package demo.technosteam;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class new_user extends AppCompatActivity {

    EditText t1,t2,t3,t4,t5;
    String s1,s2,s3,s4,s5,ReturnValue;
    String email;
    String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String regstr = "[6-9]{1}[0-9]{9}";
    String addchar="[A-Za-z/s]+";


    public void save(View v)
    {
        s1=t1.getText().toString();
        s2=t2.getText().toString();
        s3=t3.getText().toString();
        s4=t4.getText().toString();
        s5=t5.getText().toString();



        email=t4.getText().toString().trim();
        if (s1.equals("") && s2.equals("") && s3.equals("") && s4.equals("") && s5.equals("")) {
            Toast.makeText(getApplicationContext(), "Please fill all the details", Toast.LENGTH_LONG).show();
        }else if (s1.equals("")) {
            Toast.makeText(getApplicationContext(), "Field cannot be blank", Toast.LENGTH_LONG).show();
        }
        else
        if(s1.matches(addchar)==false)
        {
            Toast.makeText(getApplicationContext(),"Invalid username",Toast.LENGTH_SHORT).show();
        }
        else if (s2.equals("")) {
            Toast.makeText(getApplicationContext(), "Field cannot be blank", Toast.LENGTH_LONG).show();
        }  if (s3.equals("")) {
        Toast.makeText(getApplicationContext(), "Mobile_no cant be empty", Toast.LENGTH_SHORT).show();
        t3.setError("Mobile_no cant be empty");
    }
    else

    if(t3.getText().toString().length()<10 || s3.length()>12 || (!s3.matches(regstr))  ) {
        Toast.makeText(getApplicationContext(),"Please enter "+"\n"+" valid phone number",Toast.LENGTH_SHORT).show();
        // am_checked=0;
    }else if (s5.equals("")) {
            Toast.makeText(getApplicationContext(), "Field cannot be blank", Toast.LENGTH_LONG).show();

        }else if (t4.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "enter email address", Toast.LENGTH_SHORT).show();
        }
        else {
            if (!t4.getText().toString().trim().matches(emailPattern)) {
                Toast.makeText(getApplicationContext(), "invalid email id", Toast.LENGTH_SHORT).show();

            }
            else {
                String strurl="http://192.168.43.138/technosteam/newuser.php";
                new insertnewuser().execute(strurl);

                           }
        }
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        t1=(EditText)findViewById(R.id.editText8);
        t2=(EditText)findViewById(R.id.editText9);
        t3=(EditText)findViewById(R.id.editText10);
        t4=(EditText)findViewById(R.id.editText11);
        t5=(EditText)findViewById(R.id.editText82);
        t3.setInputType(InputType.TYPE_CLASS_NUMBER);




    }



    private class insertnewuser extends AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... params) {


            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));
            nameValuePairs.add(new BasicNameValuePair("s3", s3));
            nameValuePairs.add(new BasicNameValuePair("s4", s4));
            nameValuePairs.add(new BasicNameValuePair("s5", s5));

            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "registered" +
                    "", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();
        }
    }


}