package demo.technosteam;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.widget.CompoundButtonCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;



public class Login extends AppCompatActivity {

     EditText t1,t2;
    //EditText password;
    CheckBox showpassword;
    String s1,s2,ReturnValue;
    String email;
    String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
      Button b1;
    public void logcheck(View view)
    {
        s1=t1.getText().toString();
        s2=t2.getText().toString();

        email=t1.getText().toString().trim();

        if (s1.equals("")&&s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Both Username and Password are empty",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Username cannot be empty",Toast.LENGTH_LONG).show();
        }
        else if(s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password cannot be blank",Toast.LENGTH_LONG).show();
        }


        else if (t1.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "enter email address", Toast.LENGTH_SHORT).show();
        }
       else {
            if (t1.getText().toString().trim().matches(emailPattern)) {
                String strurl = "http://192.168.43.138/technosteam/login.php";
                new checklogin().execute(strurl);
            } else {

                Toast.makeText(getApplicationContext(), "invalid email id", Toast.LENGTH_SHORT).show();
            }
        }

    }


    public void forgot(View v)
    {
        Intent i1=new Intent(getApplicationContext(),forgot_password.class);
        startActivity(i1);
    }

    public void newuser(View v)
    {
        Intent i1=new Intent(getApplicationContext(),customer_reg.class);
        startActivity(i1);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        t1 = (EditText) findViewById(R.id.editText2);
        t2 = (EditText) findViewById(R.id.editText3);


        //password = findViewById(R.id.password);
        showpassword = (CheckBox) findViewById(R.id.showpassword);

        showpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
         @Override
          public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

         if (isChecked){
         t2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
         }
         else {
          t2.setTransformationMethod((TransformationMethod) t2);

        }
         }
    }
   );



    }

    private class checklogin extends AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... params) {

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));


            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "welcome", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();

            String type=ReturnValue.trim();

            if(type.equals("owner"))
            {
                Intent i1=new Intent(getApplicationContext(),ownerhome.class);

                Bundle bb=new Bundle();
                bb.putString("username",s1);
                i1.putExtras(bb);

                startActivity(i1);

            }
            if(type.equals("enduser"))
            {
                Intent i1=new Intent(getApplicationContext(),enduserhome.class);

                  Bundle bb=new Bundle();
                  bb.putString("username",s1);
                   i1.putExtras(bb);

                startActivity(i1);
            }
            if(type.equals("manufacture_company"))
            {
                Intent i1=new Intent(getApplicationContext(),manufacture_companyhome.class);

                Bundle bb=new Bundle();
                bb.putString("username",s1);
                i1.putExtras(bb);

                startActivity(i1);
            }
            if(type.equals("accounts"))
            {
                Intent i1=new Intent(getApplicationContext(),accountshome.class);

                Bundle bb=new Bundle();
                bb.putString("username",s1);
                i1.putExtras(bb);

                startActivity(i1);
            }







        }
    }
}
