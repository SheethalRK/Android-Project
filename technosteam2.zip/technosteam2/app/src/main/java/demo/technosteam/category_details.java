package demo.technosteam;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class category_details extends AppCompatActivity {
    EditText t1, t2;

    String s1, s2, ReturnValue;

    public void insert_category(View v) {
        s1 = t1.getText().toString();
        s2 = t2.getText().toString();


        if(s1.equals("")&&s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Category ID cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Category name cannot be blank",Toast.LENGTH_LONG).show();
        }
        else {


            String strurl = "http://192.168.43.138/technosteam/category.php";
            new cat().execute(strurl);
        }
    }

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_details);
            t1 = (EditText) findViewById(R.id.editText32);
            t2 = (EditText) findViewById(R.id.editText33);
    }

    private class cat extends AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... params) {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));

            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;
            return null;


        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "connecting", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();
        }
    }
}



