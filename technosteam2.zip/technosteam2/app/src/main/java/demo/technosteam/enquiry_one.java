package demo.technosteam;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class enquiry_one extends AppCompatActivity {
    EditText t1, t2, t3, t4, t5, t6;

    String s1, s2, s3, s4, s5, s6, ReturnValue;

    public void next(View v) {
        s1 = t1.getText().toString();
        s2 = t2.getText().toString();
        s3 = t3.getText().toString();
        s4 = t4.getText().toString();
        s5 = t5.getText().toString();
        s6 = t6.getText().toString();

        if(s1.equals("")&&s2.equals("")&&s3.equals("")&&s4.equals("")&&s5.equals("")&&s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Enquiry ID cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Person name cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s3.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Company name cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s4.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Department cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s5.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Mobile number cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Email ID cannot be blank",Toast.LENGTH_LONG).show();
        }
        else {


            Intent i1 = new Intent(getApplicationContext(), enquiry_two.class);


            Bundle bb = new Bundle();
            bb.putString("s1", s1);
            bb.putString("s2", s2);
            bb.putString("s3", s3);
            bb.putString("s4", s4);
            bb.putString("s5", s5);
            bb.putString("s6", s6);
            i1.putExtras(bb);
            startActivity(i1);
        }




    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enquiry_one);
        t1 = (EditText) findViewById(R.id.editText20);
        t2 = (EditText) findViewById(R.id.editText21);
        t3 = (EditText) findViewById(R.id.editText22);
        t4 = (EditText) findViewById(R.id.editText23);
        t5 = (EditText) findViewById(R.id.editText24);
        t6 = (EditText) findViewById(R.id.editText25);
        t5.setInputType(InputType.TYPE_CLASS_NUMBER);

    }


}

