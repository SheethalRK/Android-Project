package demo.technosteam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class enterotp extends AppCompatActivity {

    String otp,pwd;
    EditText t1;
    String s1;

    public void verify(View v)
    {
        s1 = t1.getText().toString();
        if (s1.equals(otp))
        {
            Toast.makeText(getApplicationContext(),"Your Password Is"+pwd,Toast.LENGTH_LONG).show();

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterotp);
        t1 = (EditText)findViewById(R.id.editText75);
        Bundle bb = getIntent().getExtras();
        otp = bb.getString("otp");
        pwd = bb.getString("password");


    }
}
