package demo.technosteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class enduserhome extends AppCompatActivity {

    public void addproduct (View v)
    {
        Intent i1=new Intent(getApplicationContext(),product_details.class);
        startActivity(i1);

    }
    public void show(View v)
    {
        Intent i1=new Intent(getApplicationContext(),showproduct.class);
        startActivity(i1);

    }
    public void prod(View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewproduct.class);
        startActivity(i1);

    }
    public void enquirydetails(View v)
    {
        Intent i1=new Intent(getApplicationContext(),enquiry_one.class);
        startActivity(i1);

    }
    public void addmakerequest (View v)
    {
        Intent i1=new Intent(getApplicationContext(),orderdetails_one.class);
        startActivity(i1);

    }

    public void addviewpurchase (View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewpurchase.class);
        startActivity(i1);

    }
    public void addviewquotation (View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewquotation.class);
        startActivity(i1);

    }
    public void logcheck (View v)
    {
        Intent i1=new Intent(getApplicationContext(),Login.class);
        startActivity(i1);

    }
    public void change (View v)
    {
        Intent i1=new Intent(getApplicationContext(),change_password.class);
        Bundle bb=new Bundle();
        bb.putString("username",user);
        i1.putExtras(bb);

        startActivity(i1);

    }

String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enduserhome);
        Bundle bun=getIntent().getExtras();

        user=bun.getString("username");

    }
}
