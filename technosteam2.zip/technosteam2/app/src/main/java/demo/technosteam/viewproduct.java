package demo.technosteam;

import android.content.Intent;
import android.graphics.Color;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class viewproduct extends AppCompatActivity {
    String data = "";
    TableLayout tl;
    TableRow tr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewproduct);
        StrictMode.enableDefaults();

        tl = (TableLayout) findViewById(R.id.table);

        String result = null;
        InputStream is = null;

        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.43.138/technosteam/viewproduct.php");
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();


            //Log.e(“log_tag”, “connection success“);
            //   Toast.makeText(getApplicationContext(), “pass”, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {


        }

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
                //  Toast.makeText(getApplicationContext(), “Input Reading pass”, Toast.LENGTH_SHORT).show();
            }
            is.close();

            result = sb.toString();
        } catch (Exception e) {
            //Log.e(“log_tag”, “Error converting result“ + e.toString());
            //Toast.makeText(getApplicationContext(), ”Input reading fail”, Toast.LENGTH_SHORT).show();

        }

        try {
            JSONArray jArray = new JSONArray(result);
            TableLayout tv = (TableLayout) findViewById(R.id.table);
            tv.removeAllViewsInLayout();
            int flag = 1;
            for (int i = -1; i < jArray.length(); i++) {
                TableRow tr = new TableRow(viewproduct.this);

                if (flag == 1) {
                    TextView b20 = new TextView(viewproduct.this);
                    b20.setText("Product Id");
                    b20.setTextColor(Color.BLUE);
                    b20.setTextSize(15);
                    tr.addView(b20);

                    TextView b21 = new TextView(viewproduct.this);
                    b21.setPadding(10, 0, 0, 0);
                    b21.setTextSize(15);
                    b21.setText("Category ID");
                    b21.setTextColor(Color.BLUE);
                    tr.addView(b21);

                    TextView b22 = new TextView(viewproduct.this);
                    b22.setPadding(10, 0, 0, 0);
                    b22.setText("Product Name ");
                    b22.setTextColor(Color.BLUE);
                    b22.setTextSize(15);
                    tr.addView(b22);

                    TextView b23 = new TextView(viewproduct.this);
                    b23.setPadding(10, 0, 0, 0);
                    b23.setText("Size");
                    b23.setTextColor(Color.BLUE);
                    b23.setTextSize(15);
                    tr.addView(b23);

                    TextView b24 = new TextView(viewproduct.this);
                    b24.setPadding(10, 0, 0, 0);
                    b24.setText("Steam Pressure");
                    b24.setTextColor(Color.BLUE);
                    b24.setTextSize(15);
                    tr.addView(b24);

                    TextView b25 = new TextView(viewproduct.this);
                    b25.setPadding(10, 0, 0, 0);
                    b25.setText("Condensate Load");
                    b25.setTextColor(Color.BLUE);
                    b25.setTextSize(15);
                    tr.addView(b25);

                    TextView b27 = new TextView(viewproduct.this);
                    b27.setText("Image");
                    b27.setTextColor(Color.BLUE);
                    b27.setTextSize(15);
                    tr.addView(b27);

                    TextView b28 = new TextView(viewproduct.this);
                    b28.setPadding(10, 0, 0, 0);
                    b28.setTextSize(15);
                    b28.setText("Cost");
                    b28.setTextColor(Color.BLUE);
                    tr.addView(b28);

                    TextView b29 = new TextView(viewproduct.this);
                    b29.setPadding(10, 0, 0, 0);
                    b29.setTextSize(15);
                    b29.setText("Delete");
                    b29.setTextColor(Color.BLUE);
                    tr.addView(b29);

                    TextView b30 = new TextView(viewproduct.this);
                    b30.setPadding(10, 0, 0, 0);
                    b30.setTextSize(15);
                    b30.setText("Update");
                    b30.setTextColor(Color.BLUE);
                    tr.addView(b30);


                    tv.addView(tr);
                    final View vline = new View(viewproduct.this);
                    vline.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, 2));
                    vline.setBackgroundColor(Color.BLUE);
                    tv.addView(vline);
                    flag = 0;
                } else {
                    JSONObject json_data = jArray.getJSONObject(i);
                    //Log.i("log_tag", ”id: “ + json_data.getInt(“Id”) + “, Username: “ + json_data.getString(“username”) + “, No: “ + json_data.getString(“comment”));



                    TextView b34 = new TextView(viewproduct.this);
                    b34.setPadding(10, 0, 0, 0);
                    final String stime34 = json_data.getString("pid");
                    b34.setText(stime34);
                    b34.setTextColor(Color.BLACK);
                    b34.setTextSize(15);
                    tr.addView(b34);

                    TextView b35 = new TextView(viewproduct.this);
                    b35.setPadding(10, 0, 0, 0);
                    final String stime35 = json_data.getString("cat_id");
                    b35.setText(stime35);
                    b35.setTextColor(Color.BLACK);
                    b35.setTextSize(15);
                    tr.addView(b35);

                    TextView b36 = new TextView(viewproduct.this);
                    b36.setPadding(10, 0, 0, 0);
                    final String stime36 = json_data.getString("product_name");
                    b36.setText(stime36);
                    b36.setTextColor(Color.BLACK);
                    b36.setTextSize(15);
                    tr.addView(b36);

                    TextView b37 = new TextView(viewproduct.this);
                    b37.setPadding(10, 0, 0, 0);
                    final String stime37 = json_data.getString("size");
                    b37.setText(stime37);
                    b37.setTextColor(Color.BLACK);
                    b37.setTextSize(15);
                    tr.addView(b37);

                    TextView b38 = new TextView(viewproduct.this);
                    b38.setPadding(10, 0, 0, 0);
                    final String stime38 = json_data.getString("steam_pressure");
                    b38.setText(stime38);
                    b38.setTextColor(Color.BLACK);
                    b38.setTextSize(15);
                    tr.addView(b38);

                    TextView b39 = new TextView(viewproduct.this);
                    b39.setPadding(10, 0, 0, 0);
                    b39.setTextSize(15);
                    final String stime39 = json_data.getString("condensate_load");
                    b39.setText(stime39);
                    b39.setTextColor(Color.BLACK);
                    tr.addView(b39);

                    TextView b40 = new TextView(viewproduct.this);
                    b40.setPadding(10, 0, 0, 0);
                    final String stime40 = json_data.getString("image");
                    b40.setText(stime40);
                    b40.setTextColor(Color.BLACK);
                    b40.setTextSize(15);
                    tr.addView(b40);

                    TextView b41 = new TextView(viewproduct.this);
                    b41.setPadding(10, 0, 0, 0);
                    final String stime41 = json_data.getString("cost");
                    b41.setText(stime41);
                    b41.setTextColor(Color.BLACK);
                    b41.setTextSize(15);
                    tr.addView(b41);

                    TextView b42 = new TextView(viewproduct.this);
                    b42.setPadding(10, 0, 0, 0);
                    final String stime42 ="Delete"; //json_data.getString("cost");
                    b42.setText(stime42);
                    b42.setTextColor(Color.BLACK);
                    b42.setTextSize(15);
                    tr.addView(b42);

                    TextView b43 = new TextView(viewproduct.this);
                    b43.setPadding(10, 0, 0, 0);
                    final String stime43 ="Update"; //json_data.getString("cost");
                    b43.setText(stime43);
                    b43.setTextColor(Color.BLACK);
                    b43.setTextSize(15);
                    tr.addView(b43);

                    b42.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            Intent i1=new Intent(getApplicationContext(),deleteproduct.class);

                            Bundle bb=new Bundle();

                            bb.putString("pid",stime34);
                            i1.putExtras(bb);

                            startActivity(i1);

                        }
                    });

                    b43.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent i1=new Intent(getApplicationContext(),updateproduct.class);

                            Bundle bb=new Bundle();

                            bb.putString("s1",stime34);
                            bb.putString("s2",stime35);
                            bb.putString("s3",stime36);
                            bb.putString("s4",stime37);
                            bb.putString("s5",stime38);
                            bb.putString("s6",stime39);
                            bb.putString("s7",stime40);
                            bb.putString("s8",stime41);

                            i1.putExtras(bb);

                            startActivity(i1);

                        }
                    });



                    tv.addView(tr);
                    final View vline1 = new View(viewproduct.this);
                    vline1.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, 1));
                    vline1.setBackgroundColor(Color.WHITE);
                    tv.addView(vline1);
                }
            }
        } catch (JSONException e) {
            //	Log.e(“log_tag”, “Error parsing data“ + e.toString());
            //	Toast.makeText(getApplicationContext(), “JsonArray fail”, Toast.LENGTH_SHORT).show();
        }
    }
}


