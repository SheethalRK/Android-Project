package demo.technosteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ownerhome extends AppCompatActivity {

    public void addproduct(View v)
    {
        Intent i1=new Intent(getApplicationContext(),product_details.class);
        startActivity(i1);

    }
    public void show(View v)
    {
        Intent i1=new Intent(getApplicationContext(),showproduct.class);
        startActivity(i1);

    }

    public void viewinvoice(View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewpurchase.class);
        startActivity(i1);

    }


    public void addorder (View v)
    {
        Intent i1=new Intent(getApplicationContext(),orderdetails_one.class);
        startActivity(i1);

    }

    public void addquotation (View v)
    {
        Intent i1=new Intent(getApplicationContext(),quotation_details.class);
        startActivity(i1);

    }

    public void addvieworder (View v)
    {
        Intent i1=new Intent(getApplicationContext(),vieworderrequest.class);
        startActivity(i1);

    }
    public void addviewpurchase(View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewpurchase.class);
        startActivity(i1);

    }

    public void showenq(View v)
    {
        Intent i1=new Intent(getApplicationContext(),viewenquiry.class);
        startActivity(i1);

    }


    public void addpayment(View v)
    {
        Intent i1=new Intent(getApplicationContext(),bill.class);
        startActivity(i1);

    }


    public void logcheck(View v)
    {
        Intent i1=new Intent(getApplicationContext(),Login.class);
        startActivity(i1);

    }
    public void change(View v)
    {
        Intent i1=new Intent(getApplicationContext(),change_password.class);
        Bundle bb=new Bundle();
        bb.putString("username",user);
        i1.putExtras(bb);
        startActivity(i1);

    }
    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ownerhome);

        Bundle bun=getIntent().getExtras();
        user=bun.getString("username");


    }
}
