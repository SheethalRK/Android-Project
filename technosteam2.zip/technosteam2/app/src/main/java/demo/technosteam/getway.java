package demo.technosteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class getway extends AppCompatActivity {


    public void payatm(View v)
    {
        Intent launchFacebookApplication = getPackageManager().getLaunchIntentForPackage("net.one97.paytm");
        startActivity(launchFacebookApplication);
    }
    public  void gpay(View v)
    {
        Intent launchFacebookApplication = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.nbu.paisa.user");
        startActivity(launchFacebookApplication);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getway);
    }
}
