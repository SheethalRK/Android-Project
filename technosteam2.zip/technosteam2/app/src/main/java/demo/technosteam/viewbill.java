package demo.technosteam;

import android.graphics.Color;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class viewbill extends AppCompatActivity {

    String data = "";
    TableLayout tl;
    TableRow tr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewbill);

        StrictMode.enableDefaults();

        tl = (TableLayout) findViewById(R.id.table);

        String result = null;
        InputStream is = null;

        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http:192.168.43.138/technosteam/viewbill.php");
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();


            //Log.e(“log_tag”, “connection success“);
            //   Toast.makeText(getApplicationContext(), “pass”, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {


        }

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
                //  Toast.makeText(getApplicationContext(), “Input Reading pass”, Toast.LENGTH_SHORT).show();
            }
            is.close();

            result = sb.toString();
        } catch (Exception e) {
            //Log.e(“log_tag”, “Error converting result“ + e.toString());
            //Toast.makeText(getApplicationContext(), ”Input reading fail”, Toast.LENGTH_SHORT).show();

        }

        try {
            JSONArray jArray = new JSONArray(result);
            TableLayout tv = (TableLayout) findViewById(R.id.table);
            tv.removeAllViewsInLayout();
            int flag = 1;
            for (int i = -1; i < jArray.length(); i++) {
                TableRow tr = new TableRow(viewbill.this);

                if (flag == 1) {
                    TextView b20 = new TextView(viewbill.this);
                    b20.setPadding(10, 0, 0, 0);
                    b20.setText("Order Id");
                    b20.setTextColor(Color.BLUE);
                    b20.setTextSize(15);
                    tr.addView(b20);

                    TextView b21 = new TextView(viewbill.this);
                    b21.setPadding(10, 0, 0, 0);
                    b21.setTextSize(15);
                    b21.setText("Customer ID");
                    b21.setTextColor(Color.BLUE);
                    tr.addView(b21);

                    TextView b22 = new TextView(viewbill.this);
                    b22.setPadding(10, 0, 0, 0);
                    b22.setText("Bill Number ");
                    b22.setTextColor(Color.BLUE);
                    b22.setTextSize(15);
                    tr.addView(b22);

                    TextView b23 = new TextView(viewbill.this);
                    b23.setPadding(10, 0, 0, 0);
                    b23.setText("Total Ammount");
                    b23.setTextColor(Color.BLUE);
                    b23.setTextSize(15);
                    tr.addView(b23);

                    TextView b24 = new TextView(viewbill.this);
                    b24.setPadding(10, 0, 0, 0);
                    b24.setText("Mode Of Payment");
                    b24.setTextColor(Color.BLUE);
                    b24.setTextSize(15);
                    tr.addView(b24);




                    tv.addView(tr);
                    final View vline = new View(viewbill.this);
                    vline.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, 2));
                    vline.setBackgroundColor(Color.BLUE);
                    tv.addView(vline);
                    flag = 0;
                } else {
                    JSONObject json_data = jArray.getJSONObject(i);
                    //Log.i("log_tag", ”id: “ + json_data.getInt(“Id”) + “, Username: “ + json_data.getString(“username”) + “, No: “ + json_data.getString(“comment”));



                    TextView b34 = new TextView(viewbill.this);
                    b34.setPadding(10, 0, 0, 0);
                    final String stime34 = json_data.getString("orderid");
                    b34.setText(stime34);
                    b34.setTextColor(Color.BLACK);
                    b34.setTextSize(15);
                    tr.addView(b34);

                    TextView b35 = new TextView(viewbill.this);
                    b35.setPadding(10, 0, 0, 0);
                    final String stime35 = json_data.getString("customerid");
                    b35.setText(stime35);
                    b35.setTextColor(Color.BLACK);
                    b35.setTextSize(15);
                    tr.addView(b35);

                    TextView b36 = new TextView(viewbill.this);
                    b36.setPadding(10, 0, 0, 0);
                    final String stime36 = json_data.getString("bill_no");
                    b36.setText(stime36);
                    b36.setTextColor(Color.BLACK);
                    b36.setTextSize(15);
                    tr.addView(b36);

                    TextView b37 = new TextView(viewbill.this);
                    b37.setPadding(10, 0, 0, 0);
                    final String stime37 = json_data.getString("total_amt");
                    b37.setText(stime37);
                    b37.setTextColor(Color.BLACK);
                    b37.setTextSize(15);
                    tr.addView(b37);

                    TextView b38 = new TextView(viewbill.this);
                    b38.setPadding(10, 0, 0, 0);
                    final String stime38 = json_data.getString("mode_of_payment");
                    b38.setText(stime38);
                    b38.setTextColor(Color.BLACK);
                    b38.setTextSize(15);
                    tr.addView(b38);






                    tv.addView(tr);
                    final View vline1 = new View(viewbill.this);
                    vline1.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, 1));
                    vline1.setBackgroundColor(Color.WHITE);
                    tv.addView(vline1);
                }
            }
        } catch (JSONException e) {
            //	Log.e(“log_tag”, “Error parsing data“ + e.toString());
            //	Toast.makeText(getApplicationContext(), “JsonArray fail”, Toast.LENGTH_SHORT).show();
        }
    }
}


    
