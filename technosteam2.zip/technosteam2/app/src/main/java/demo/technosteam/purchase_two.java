package demo.technosteam;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class purchase_two extends AppCompatActivity {
    EditText t6, t7, t8, t9;

    String s1, s2, s3, s4, s5,s6, s7, s8, s9, ReturnValue;

    public void save(View v) {
        s6 = t6.getText().toString();
        s7 = t7.getText().toString();
        s8 = t8.getText().toString();
        s9 = t9.getText().toString();

        if(s6.equals("")&&s7.equals("")&&s8.equals("")&&s9.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s7.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s8.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s9.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else {


            String strurl = "http://192.168.43.138/technosteam/purchase.php";
            new insert_purchase2().execute(strurl);
        }


    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase_two);
        t6 = (EditText) findViewById(R.id.editText51);
        t7 = (EditText) findViewById(R.id.editText52);
        t8 = (EditText) findViewById(R.id.editText53);
        t9 = (EditText) findViewById(R.id.editText54);

        Bundle bun=getIntent().getExtras();
        s1=bun.getString("s1");
        s2=bun.getString("s2");
        s3=bun.getString("s3");
        s4=bun.getString("s4");
        s5=bun.getString("s5");


    }

    private class insert_purchase2 extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));
            nameValuePairs.add(new BasicNameValuePair("s3", s3));
            nameValuePairs.add(new BasicNameValuePair("s4", s4));
            nameValuePairs.add(new BasicNameValuePair("s5", s5));

            nameValuePairs.add(new BasicNameValuePair("s6", s6));
            nameValuePairs.add(new BasicNameValuePair("s7", s7));
            nameValuePairs.add(new BasicNameValuePair("s8", s8));
            nameValuePairs.add(new BasicNameValuePair("s9", s9));


            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;
            return null;


        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "connecting", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();
        }
    }


}
