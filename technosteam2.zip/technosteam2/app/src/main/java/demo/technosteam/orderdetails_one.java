package demo.technosteam;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class orderdetails_one extends AppCompatActivity {
    EditText t1, t2, t3, t4, t5, t6;

    String s1, s2, s3, s4, s5, s6, ReturnValue;

    private DatePicker datePicker;
    private Calendar calendar;

    private int year, month, day;


    public void next(View v) {
        s1 = t1.getText().toString();
        s2 = t2.getText().toString();
        s3 = t3.getText().toString();
        s4 = t4.getText().toString();
        s5 = t5.getText().toString();
        s6 = t6.getText().toString();

        if(s1.equals("")&&s2.equals("")&&s3.equals("")&&s4.equals("")&&s5.equals("")&&s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s3.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s4.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s5.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else {

            Intent i1 = new Intent(getApplicationContext(), orderdetails_two.class);


            Bundle bb = new Bundle();
            bb.putString("s1", s1);
            bb.putString("s2", s2);
            bb.putString("s3", s3);
            bb.putString("s4", s4);
            bb.putString("s5", s5);
            bb.putString("s6", s6);
            i1.putExtras(bb);
            startActivity(i1);
        }




    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderdetails_one);
        t1 = (EditText) findViewById(R.id.editText34);
        t2 = (EditText) findViewById(R.id.editText35);
        t3 = (EditText) findViewById(R.id.editText36);
        t4 = (EditText) findViewById(R.id.editText37);
        t5 = (EditText) findViewById(R.id.editText38);
        t6 = (EditText) findViewById(R.id.editText39);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month+1, day);
    }

    @SuppressWarnings("deprecation")
    public void setdate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2+1, arg3);
                }
            };

    private void showDate(int year, int month, int day) {
        t2.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

}