package demo.technosteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class accountshome extends AppCompatActivity {

    public void addvieworder(View v)
    {
        Intent i1=new Intent(getApplicationContext(),vieworderrequest.class);
        startActivity(i1);

    }
    public void logcheck(View v)
    {
        Intent i1=new Intent(getApplicationContext(),Login.class);
        startActivity(i1);

    }

    public void genbill(View v)
    {
        Intent i1=new Intent(getApplicationContext(),generatebill.class);
        startActivity(i1);

    }
    public void geninvoice(View v)
    {
        Intent i1=new Intent(getApplicationContext(),purchase_one.class);
        startActivity(i1);
    }
    public void change(View v)
    {
        Intent i1=new Intent(getApplicationContext(),change_password.class);
        Bundle bb=new Bundle();
        bb.putString("username",user);
        i1.putExtras(bb);
        startActivity(i1);

    }

    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountshome);

        Bundle bun=getIntent().getExtras();

        user=bun.getString("username");
    }
}
