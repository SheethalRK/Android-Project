package demo.technosteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class enduser extends AppCompatActivity {

    String user;

    public void change(View v)
    {
        Intent i1=new Intent(getApplicationContext(),change_password.class);

        Bundle bb=new Bundle();
        bb.putString("username",user);
        i1.putExtras(bb);

        startActivity(i1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enduser);

        Bundle bun=getIntent().getExtras();
        user=bun.getString("username");




    }
}
