package demo.technosteam;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class sales_details extends AppCompatActivity {
    EditText t1, t2, t3, t4, t5, t6, t7, t8;

    String s1, s2, s3, s4, s5, s6, s7, s8, ReturnValue;

    private DatePicker datePicker;
    private Calendar calendar;

    private int year, month, day;

    public void save(View v) {
        s1 = t1.getText().toString();
        s2 = t2.getText().toString();
        s3 = t3.getText().toString();
        s4 = t4.getText().toString();
        s5 = t5.getText().toString();
        s6 = t6.getText().toString();
        s7 = t7.getText().toString();
        s8 = t8.getText().toString();

        if(s1.equals("")&&s2.equals("")&&s3.equals("")&&s4.equals("")&&s5.equals("")&&s6.equals("")&&s7.equals("")&&s8.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please fill all the details",Toast.LENGTH_LONG).show();
        }
        else if (s1.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s2.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s3.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s4.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s5.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s6.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s7.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else if (s8.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Field cannot be blank",Toast.LENGTH_LONG).show();
        }
        else {

            String strurl = "http://192.168.43.138/technosteam/sales.php";
            new insert_sales().execute(strurl);
        }








    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_details);
        t1 = (EditText) findViewById(R.id.editText62);
        t2 = (EditText) findViewById(R.id.editText63);
        t3 = (EditText) findViewById(R.id.editText64);
        t4 = (EditText) findViewById(R.id.editText65);
        t5 = (EditText) findViewById(R.id.editText66);
        t6 = (EditText) findViewById(R.id.editText67);
        t7 = (EditText) findViewById(R.id.editText68);
        t8 = (EditText) findViewById(R.id.editText69);

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month+1, day);


    }

    public void setdate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2+1, arg3);
                }
            };

    private void showDate(int year, int month, int day) {
        t3.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

    private class insert_sales extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("s1", s1));
            nameValuePairs.add(new BasicNameValuePair("s2", s2));
            nameValuePairs.add(new BasicNameValuePair("s3", s3));
            nameValuePairs.add(new BasicNameValuePair("s4", s4));
            nameValuePairs.add(new BasicNameValuePair("s5", s5));
            nameValuePairs.add(new BasicNameValuePair("s6", s6));
            nameValuePairs.add(new BasicNameValuePair("s7", s7));
            nameValuePairs.add(new BasicNameValuePair("s8", s8));

            DbHttpResponse myHttpResponse = new DbHttpResponse();
            String rspTxt = myHttpResponse.getResponseString(params[0], nameValuePairs);

            ReturnValue = rspTxt;
            return null;


        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(), "connecting", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            int startval = 0;
            startval = ReturnValue.indexOf("<!DOCTYPE");

            if (startval > 0) {
                ReturnValue = ReturnValue.substring(0, startval);
            }

            ReturnValue = ReturnValue.replace("\r\n\r\n", "");
            Toast.makeText(getApplicationContext(), ReturnValue, Toast.LENGTH_LONG).show();
        }
    }
}


